//------------------------------------------------------------------------------
//
// File Name:	stdafx.cpp
// Author(s):	Jeremy Kings (j.kings)
// Project:		Beta Engine
// Course:		WANIC VGP2
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------
#include "stdafx.h"

/* NOTE: there must be at least one empty line after the #include, or the compiler gets confused */
