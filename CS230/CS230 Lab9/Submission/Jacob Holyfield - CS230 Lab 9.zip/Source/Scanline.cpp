#include "stdafx.h"
#include "Scanline.h"

Effects::Scanline::Scanline() : PostEffect("Scanline.frag")
{
}

void Effects::Scanline::Draw()
{
}
