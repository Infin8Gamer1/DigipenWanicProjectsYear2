#include "stdafx.h"
#include "Vignette.h"

// Systems
#include <ShaderProgram.h>
#include <Graphics.h>

Effects::Vignette::Vignette() : PostEffect("vignette.frag")
{
}

void Effects::Vignette::Draw()
{
}
