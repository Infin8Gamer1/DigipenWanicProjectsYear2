#include "stdafx.h"
#include "Noise.h"

// Systems
#include <ShaderProgram.h>
#include <Graphics.h>

Effects::Noise::Noise() : PostEffect("Noise.frag")
{
}

void Effects::Noise::Draw()
{
}


