//------------------------------------------------------------------------------
//
// File Name:	Trace.h
// Author(s):	 Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2 2018-2019
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include "BetaObject.h"

//------------------------------------------------------------------------------

class Trace : public BetaObject
{
public:
	//------------------------------------------------------------------------------
	// Public Functions:
	//------------------------------------------------------------------------------

	// Creates a trace/logging module.
	// Params:
	//   filename = File that will be written to.
	Trace(const std::string& filename = "trace.log");

	// Destroys the trace/logging module.
	~Trace();

	// Access the current stream to output a message
	std::ostream& GetStream();

private:
	//------------------------------------------------------------------------------
	// Private Variables:
	//------------------------------------------------------------------------------
	
	std::ostream traceStream;
	std::ofstream traceFile;
	bool fileOpened;
};

/*----------------------------------------------------------------------------*/
