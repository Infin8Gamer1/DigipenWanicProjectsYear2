//------------------------------------------------------------------------------
//
// File Name:	Parser.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		CS230
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include <exception>

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Forward References:
//------------------------------------------------------------------------------

typedef class Vector2D Vector2D;
typedef class ParseException ParseException;

//------------------------------------------------------------------------------
// Public Structures:
//------------------------------------------------------------------------------

// You are free to change the contents of this structure as long as you do not
//   modify the public interface (function prototypes) declared in the header.
class Parser
{
public:
	// Opens a file for loading.
	// Returns:
	//   True if load was successful, false otherwise.
	Parser(const std::string& filename, std::ios_base::openmode mode = std::ios_base::in | std::ios_base::out);

	// Closes the currently open file.
	~Parser();

	// Begins a new scope when writing to a file.
	// Outputs a curly brace and increases the tab count.
	void BeginScope();

	// Ends the current scope when writing to a file.
	// Outputs an end curly brace and decreases tab count.
	void EndScope();

	// Writes a variable name and value to the currently open file.
	template<typename T>
	void WriteVariable(const std::string& name, const T& variable)
	{
		if (!stream.is_open()) return;

		for (unsigned i = 0; i < indentLevel; ++i)
			stream << tab;
		stream << name << " : " << variable << std::endl;
	}

	// Writes a value to the currently open file.
	template<typename T>
	void WriteValue(const T& value)
	{
		if (!stream.is_open()) return;

		for (unsigned i = 0; i < indentLevel; ++i)
			stream << tab;
		stream << value << std::endl;
	}

	// Reads the value of a variable with the given name from the currently open file.
	// Returns:
	//   True if read was successful, false otherwise.
	template<typename T>
	void ReadVariable(const std::string& name, T& variable)
	{
		if (!stream.is_open()) return;

		std::string nextWord;
		stream >> nextWord;

		if (nextWord != name)
			throw ParseException(name, filename);

		ReadSkip(':');
		stream >> variable;
	}

	// Reads the next value from the currently open file.
	// Returns:
	//   True if read was successful, false otherwise.
	template<typename T>
	void ReadValue(T& value)
	{
		stream >> value;
	}

	// Reads a piece of text from the currently open file
	// and skips to the next word afterwards.
	void ReadSkip(const std::string& text);

	// Skips characters in the stream up until the next
	// occurrence of the given delimiter.
	void ReadSkip(char delimiter);

private:
	//------------------------------------------------------------------------------
	// Private Structures:
	//------------------------------------------------------------------------------

	class ParseException : public std::exception
	{
	public:
		ParseException(const std::string& variableName, const std::string& fileName);
	private:
		std::string variableName;
		std::string fileName;
	};

	//------------------------------------------------------------------------------
	// Private Variables:
	//------------------------------------------------------------------------------

	std::fstream stream;
	std::string filename;
	unsigned indentLevel;
	const char* tab = "  ";
};
