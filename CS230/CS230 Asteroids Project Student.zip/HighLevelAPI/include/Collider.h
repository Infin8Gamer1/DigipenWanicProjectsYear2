//------------------------------------------------------------------------------
//
// File Name:	Collider.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include "Component.h"
#include "EventManager.h"

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public Consts:
//------------------------------------------------------------------------------

typedef enum ColliderType
{
	ColliderTypeCircle,
	ColliderTypeLine,
} ColliderType;

//------------------------------------------------------------------------------
// Public Structures:
//------------------------------------------------------------------------------

// Collision event - Generated when two objects collide
struct CollisionEvent : public Event
{
	CollisionEvent(GameObject& otherObject);
	GameObject& otherObject;
};

// Collider class - Detects collisions between objects
class Collider : public Component
{
public:
	//------------------------------------------------------------------------------
	// Public Functions:
	//------------------------------------------------------------------------------

	// Allocate a new collider component.
	// Params:
	//   owner = Reference to the object that owns this component.
	Collider(ColliderType type);

	// Destructor for Collider class.
	// Virtual so that correct destructor is called upon deletion.
	virtual ~Collider();

	// Logic update for this component.
	void FixedUpdate(float dt);

	// Check if two objects are colliding.
	// (Hint: Refer to the project instructions for implementation suggestions.)
	// (Hint: Make sure to call the handler for both colliders, passing the 
	//	  owner game object references in the correct order!)
	// Params:
	//	 other = Reference to the second collider component.
	void CheckCollision(const Collider& other);

	// Perform intersection test between two arbitrary colliders.
	// Params:
	//	 other = Reference to the second collider component.
	virtual bool IsCollidingWith(const Collider& other) const = 0;

	// Get the type of this component.
	ColliderType GetType() const;

	// Has this component been checked for collisons?
	bool WasProcesed() const;

	// Set this collider's processed bool.
	void SetProcessed(bool value);

private:
	//------------------------------------------------------------------------------
	// Private Variables:
	//------------------------------------------------------------------------------

	// The type of collider used by this component.
	// (Currently, Circle or Line).
	ColliderType type;

	// Whether the collider has been checked for collisions this frame.
	bool processed;
};

//------------------------------------------------------------------------------
