//------------------------------------------------------------------------------
//
// File Name:	Reactive.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2 2018-2019
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include "Component.h"

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Forward References:
//------------------------------------------------------------------------------

typedef class GameObject GameObject;
typedef class Vector2D Vector2D;

//------------------------------------------------------------------------------
// Public Consts:
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public Structures:
//------------------------------------------------------------------------------

typedef void(*MouseEventHandler)(GameObject& gameObject1);

class Reactive : public Component
{
public:
	//------------------------------------------------------------------------------
	// Public Functions:
	//------------------------------------------------------------------------------

	// Allocate a new Reactive component.
	Reactive();

	// Dynamically allocates a copy of a Reactive component.
	Component* Clone() const;

	// Check if the mouse is currently intersecting with this object.
	void Update(float dt);

	// Set the mouse enter event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the mouse starts being over them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse enter event handler (may be NULL).
	void SetMouseEnterEventHandler(MouseEventHandler handler);

	// Set the mouse over event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the mouse is over them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse over event handler (may be NULL).
	void SetMouseOverEventHandler(MouseEventHandler handler);

	// Set the mouse leave event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the stops being over them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse leave event handler (may be NULL).
	void SetMouseLeaveEventHandler(MouseEventHandler handler);

	// Set the mouse click event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the mouse is clicked on them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse click event handler (may be NULL).
	void SetMouseClickEventHandler(MouseEventHandler handler);

	// Set the mouse down event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the mouse is down on them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse down event handler (may be NULL).
	void SetMouseDownEventHandler(MouseEventHandler handler);

	// Set the mouse up event handler for a Reactive component.
	// (Hint: This allows other components, such as behaviors, to respond when the mouse button is no longer clicked on them.)
	// (Note: It is acceptable for the handler to be NULL.  This allows an existing handler to be removed.)
	// Params:
	//	 handler = Pointer to the mouse up event handler (may be NULL).
	void SetMouseUpEventHandler(MouseEventHandler handler);

	// Obtains the mouse's position in world coordinates.
	// Returns:
	//   The position of the mouse as a vector.
	static Vector2D GetMouseWorldPosition();

	// Save object data to file.
	// Params:
	//   parser = The parser object used to save the object's data.
	void Serialize(Parser& parser) const;

	// Load object data from file
	// Params:
	//   parser = The parser object used to load the object's data.
	void Deserialize(Parser& parser);

private:
	//------------------------------------------------------------------------------
	// Private Variables:
	//------------------------------------------------------------------------------

	// Pointer to a function that handles collisions between the mouse and an object.
	MouseEventHandler mouseEnter;
	MouseEventHandler mouseOver;
	MouseEventHandler mouseLeave;

	// Pointers to functions that handle mouse clicks.
	MouseEventHandler mouseClick;
	MouseEventHandler mouseDown;
	MouseEventHandler mouseUp;

	// Whether the mouse button is currently down.
	bool mouseIsDown;

	// Whether the mouse is currently over the object.
	bool mouseIsOver;
};

//------------------------------------------------------------------------------
