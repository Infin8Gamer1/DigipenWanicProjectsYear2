//------------------------------------------------------------------------------
//
// File Name:	ResourceManager.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		CS230
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Forward References:
//------------------------------------------------------------------------------

typedef class Mesh Mesh;
typedef class SpriteSource SpriteSource;

//------------------------------------------------------------------------------
// Public Structures:
//------------------------------------------------------------------------------

class ResourceManager
{
public:
	//------------------------------------------------------------------------------
	// Public Functions:
	//------------------------------------------------------------------------------

	// Constructor(s)
	ResourceManager();

	// Destructor
	~ResourceManager();

	// Create an association between a mesh and a particular type of object
	void AddMesh(const std::string& objectName, Mesh* mesh);

	// Retrieve an existing mesh required by a game object.
	// Params:
	//   objectName = The name of the mesh.
	//   createIfNotFound = Whether to create a default quad mesh if no mesh is found.
	Mesh* GetMesh(const std::string& objectName, bool createIfNotFound = true);

	// Retrieve a sprite source that uses a given texture, create it if not found.
	// Params:
	//	 textureName = Filename of the texture used by the sprite source.
	//	 numCols = The number of columns in the sprite sheet.
	//	 numRows = The number of rows in the sprite sheet.
	SpriteSource* GetSpriteSource(const std::string& textureName, int numCols = 1, int numRows = 1);

	// Loads a non-looping FMOD sound.
	// Params:
	//	 filename = Filename of the sound being added to the resource manager.
	void LoadSoundFX(const std::string& filename);

	// Loads an FMOD stream for a music file.
	// Params:
	//	 filename = Filename of the BGM being added to the resource manager.
	void LoadSoundBGM(const std::string& filename);

	// Unloads all resources used by the resource manager.
	void Shutdown();

private:
	//------------------------------------------------------------------------------
	// Private Functions:
	//------------------------------------------------------------------------------

	// Create a sprite source for a given texture.
	// Params:
	//	 textureName = Filename of the texture used by the sprite source.
	//	 numCols = The number of columns in the sprite sheet.
	//	 numRows = The number of rows in the sprite sheet.
	SpriteSource* CreateSpriteSource(const std::string& textureName, int numCols, int numRows);

	// Free all level objects
	void FreeLevels(void);

	// Free all meshes associated with any created game objects.
	void FreeMeshes(void);

	// Free all sprite source objects.
	void FreeSpriteSources(void);

	// Free all sound objects
	void FreeSounds(void);

	//------------------------------------------------------------------------------
	// Private Variables:
	//------------------------------------------------------------------------------

	// Array containing all meshes used by objects
	typedef std::map<const std::string, Mesh*> MeshMap;
	MeshMap meshes;

	// Array containing sprite sources used by objects
	std::vector<SpriteSource*> spriteSources;

	// Array containing sounds used by objects
	std::vector<std::string> soundNames;
};

//------------------------------------------------------------------------------
