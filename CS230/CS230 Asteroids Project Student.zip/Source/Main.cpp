//------------------------------------------------------------------------------
//
// File Name:	Main.cpp
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2 2018-2019
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include "stdafx.h"

// BetaFramework Engine
#include <Engine.h>

// Engine modules
#include <SpaceManager.h>
#include <GameObjectFactory.h>
#include <EventManager.h>

// Initial game state
#include "Level1.h"

// Custom components
#include "TimedDeath.h"
#include "PlayerShip.h"
#include "Asteroid.h"
#include "ScreenWrap.h"
#include "PlayerProjectile.h"

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public Functions:
//------------------------------------------------------------------------------

// Main function
int WINAPI WinMain(_In_ HINSTANCE instance, _In_opt_ HINSTANCE prevInstance, _In_ LPSTR command_line, _In_ int show)
{
	// Enable memory leak checking
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	_CrtSetReportMode(_CRT_ERROR, _CRTDBG_MODE_DEBUG);

	// Unused parameters
	UNREFERENCED_PARAMETER(prevInstance);
	UNREFERENCED_PARAMETER(command_line);
	UNREFERENCED_PARAMETER(show);
	UNREFERENCED_PARAMETER(instance);

	// Set initial game state to the second level.
	SpaceManager* spaceManager = new SpaceManager();
	spaceManager->GetDefaultSpace().SetLevel<Levels::Level1>();

	// Add additional modules to engine
	Engine::GetInstance().AddModule(spaceManager);

	// TO-DO: Add event manager to engine

	// Register custom components with factory
	GameObjectFactory::GetInstance().RegisterComponent(new Behaviors::TimedDeath());
	GameObjectFactory::GetInstance().RegisterComponent(new Behaviors::PlayerShip());

	// TO-DO: Register additional components with the factory

	// Game engine goes!
	Engine::GetInstance().Start(instance, 800, 600);

	return 0;
}
