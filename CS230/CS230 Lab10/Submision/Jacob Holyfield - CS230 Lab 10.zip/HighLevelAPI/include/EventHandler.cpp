#include "stdafx.h"
#include "EventHandler.h"

void EventHandler::HandleEvent(const Event & event)
{
}

EventHandler::EventHandler()
{
}

EventHandler::~EventHandler()
{
}
